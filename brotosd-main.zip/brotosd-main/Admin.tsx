
import React from 'react';

// This component is deprecated as the site is now exclusively for the Consultant System.
export const AdminPage: React.FC = () => (
    <div className="min-h-screen flex items-center justify-center">
        <p>Admin deprecated.</p>
    </div>
);
