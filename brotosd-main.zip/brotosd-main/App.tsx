
import React from 'react';
import { ConsultantApp } from './ConsultantSystem';

export default function App() {
  return <ConsultantApp />;
}
